<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Type_document extends Model
{
    protected $table="type_document";

	protected $guarded = [];
}
